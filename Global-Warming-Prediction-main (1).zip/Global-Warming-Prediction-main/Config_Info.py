def get_config():
    config = {
    "apiKey": "AIzaSyBR2ryTweESnWAqXbG0NdwKsBNAbCNuHRQ",
    "authDomain": "myproject-6b5bf.firebaseapp.com",
    "databaseURL": "https://myproject-6b5bf-default-rtdb.firebaseio.com",
    "projectId": "myproject-6b5bf",
    "storageBucket": "myproject-6b5bf.appspot.com",
    "messagingSenderId": "848235750488",
    "appId": "1:848235750488:web:00de8b66acddd04a91562d",
    "measurementId": "G-LHYMQ2T95X"
    }
    return config

def Password():
    password = "inception"
    return password