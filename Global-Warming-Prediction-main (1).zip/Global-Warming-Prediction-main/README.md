# Global_Warming_predc.
This project focuses to provide an overview of where machine learning can be applied in the fight against climate change.
We are spreading Global Warming awareness with the help of this project.

Applying Machine Learning Algorithms
• Linear Regression
• Random Forest
• ARIMA (Auto Regressive Integrated Moving Average)

• Aim:
To Design a Model to accomplish Analysis of Global
Warming using Machine Learning.

• Objectives:
The Main Obiective is to predict temperature.
To capture the relationship between CO2 and temperature to analyze the combat cause of Global Warming.

Hardware Requirements
Processor: Quad core Intel i3 or higher
Computer architecture bit widths: 64-bits
RAM: 4 GB or higher
Hard disk space: 16 GB or higher
Internet Connection: Required

Software Requirements
• Languages Python
• IDE(Integrated Desktop Environment) Jupiter Notebook

Tech Stack
1. HTML and CSS- Frontend
2. Flask- Backend

<img width="1252" alt="Screenshot 2023-02-08 at 12 27 37 AM" src="https://user-images.githubusercontent.com/90505751/217340037-54d1a506-44c1-4949-8a17-5fc350097ba5.png">




